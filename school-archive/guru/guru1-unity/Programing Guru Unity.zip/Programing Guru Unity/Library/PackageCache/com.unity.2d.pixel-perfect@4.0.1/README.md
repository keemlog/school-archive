# 2D Pixel Perfect
Quick start guide:
1. Add *Pixel Perfect Camera* component to your main camera.
2. Set *Assets Pixels Per Unit* and *Reference Resolution*.
3. Enter Play Mode and see the result.
